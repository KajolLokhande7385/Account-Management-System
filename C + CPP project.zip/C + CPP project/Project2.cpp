//Account Management System

#include<iostream>
#include<string.h>
using namespace std;
class Account
{
    protected:
        int accno;
        char name[20];
         int age;
         char gender[20];
        float bal;



    public:
        void set()
        {
            cout<<"enter Accno :";
            cin>>accno;
            cout<<"enter Name  :";
            cin>>name;
            cout<<"enter Age   :";
            cin>>age;
            cout<<"enter Gender:";
            cin>>gender;
            cout<<"enter Bal   :";
            cin>>bal;
                    }

        void display()
        {
            cout<<"\nAccno  :"<<accno;
            cout<<"\nName   :"<<name;
            cout<<"\nAge    :"<<age;
            cout<<"\nGender :"<<gender;
            cout<<"\nBal    :"<<bal;

        }

        void deposit(int amt)
        {
            bal=bal+amt;
            cout<<"deposit successfully...";
        }
        void withdraw(int amt)
        {
            bal=bal-amt;
            cout<<"withdraw successfully...";
        }
};

class Saving :public Account
{
    int intrest;

public:
    void setS()
    {
        set();
        cout<<"enter Intrest:";
        cin>>intrest;
    }

    void displayS()
    {
        display();
        cout<<"\nIntrest:"<<intrest;
    }

    void deposit(int amt)
    {
        bal=bal+amt+intrest;
        cout<<"\ndeposit successfully...";
    }

    void withdraw(int amt)
    {
        bal=bal-amt+intrest;
        cout<<"\nwithdraw successfully...";
    }
};

class Current : public Account
{
    int charges;

public:
    void setC()
    {
        set();
        cout<<"enter Charges:";
        cin>>charges;
    }

    void displayC()
    {
        display();
        cout<<"\nCharges:"<<charges;
    }

    void deposit(int amt)
    {
        bal=bal+amt-charges;
        cout<<"\ndeposit successfully...";
    }

    void withdraw(int amt)
    {
        bal=bal-amt-charges;
        cout<<"\nwithdraw successfully...";
    }
};

main()
{

    int N;
    int i;
    int j=1234;

    Account *a[N];

    cout<<"enter Number of Accounts:";
    cin>>N;

    int count =0;
    int choice;

    cout<<"Account Information\n";
    Account z;
    z.set();
    z.display();


    while(1)
    {
        cout<<"\n\n\t*************************************************\n";
        cout<<"\t\t~ACCOUNT MANAGEMENTS SYSTEM~\n";
        cout<<"\t*************************************************\n";
        cout<<"\npress 1. to create saving account \npress 2. to create current account \npress 3. deposit \npress 4. withdraw \npress 5. show all accounts \npress 6. search account by account no \npress 7. show account with highest balance \npress 8. exit\n";

        cout<<"\nenter choice:";
        cin>>choice;

        switch(choice)
        {
        case 1:
            Saving s;
            s.setS();
            s.display();
            a[count]=&s;
            count++;
            cout<<"\nSaving account created successfully...";
            break;

        case 2:
            Current c;
            c.setC();
            c.displayC();
            a[count]=&s;
            count++;
            cout<<"\nCurrent account created successfully...";
            break;


       case 3:
           cout<<"\nsaving....";
            s.deposit (500);
            s.display();
            a[count]=&s;
            count++;

            cout<<"\ncurreent....";
            c.deposit(200);
            c.display();
            a[count]=&s;
            count++;
            break;

       case 4:
            cout<<"\nsaving....";
           s.withdraw(100);
           s.display();
           a[count]=&s;
           count++;

           cout<<"\ncurrent....";
           c.withdraw (200);
           c.display();
           a[count]=&s;
           count++;
           break;

       case 5:

           /*Account z;
           z.display();

           cout<<"\n";

            Saving t;
            t.displayS();
            cout<<"\n";

            Current l;
            l.displayC();
            cout<<"\n";


            //a[count]=&s;
            //count++;
            break;
*/
           for(i=0;i<count;i++)
           {
               a[i]->display();
           }
           a[count]=&s;
           count++;

           a[count]=&c;
           count++;
           break;

       case 6:
            for(i=0;i<count;i++)
            {
                if(j==accno)
                {
                    cout<<"Account search successfully...";
                }

            }
            //a[count]=&s;
            //count++;

            //a[count]=&c;
           // count++;

            break;
        }
    }
}

