//bank management system
#include<iostream>
#include<string.h>
using namespace std;
class Bank
{
protected:
    char name[100],add[100],y[10];
    int bal,a,accno,p,max=1;

 public:

    void open_account();
    void deposit_money();
    void withdraw_money();
    void Display_account();
    void search_account();
    void display_account();
    void show_account();


};

void Bank::open_account()
{
    cout<<"enter your full name :";
    cin.ignore();
    cin.getline(name,100);

    cout<<"enter your address :";
    cin.ignore();
    cin.getline(add,100);

    cout<<"enter your account no:";
    cin>>accno;

    cout<<"what type of account you want to open saving (s) or current (c): ";
    cin>>y;

    cout<<"enter amount for deposite :";
    cin>>bal;

    cout<<"your account is created successfully...!!!\n\n";
}

void Bank :: deposit_money()
{

    cout<<"deposit:\n";
    cout<<"enter how much you deposite :";
    cin>>a;

    bal+=a;
    cout<<"\ntotal amount you deposite :"<<bal<<"\n";
}

void Bank ::Display_account()
{
    cout<<"\nyour full name :"<<name;
    cout<<"\nyour address :"<<add;
    cout<<"\nyour accno:"<<accno;
    cout<<"\ntype of account that you open:"<<y;
    cout<<"\namount you deposit :"<<bal<<"\n\n";
}

void Bank ::withdraw_money()
{
    float amount;
    cout<<"withdraw:\n";
    cout<<"enter how much you withdraw :";
    cin>>amount;

    bal-=amount;
    cout<<"\ntotal amount is left :"<<bal<<"\n";

}

void Bank:: search_account()
{
    cout<<"search...\n";
    cout<<"enter accno:";
    cin>>p;
    if(accno==p)
    {
        cout<<"successfully search the account\n\n";
    }
    else
    {
        cout<<"sorry such account is not created\n\n";
    }

}

void Bank::show_account()
{


    if(bal>max)
    {
        max=bal;
    }
}
int main()

{
    int ch;
    Bank b;

    while(1)
    {
    cout<<"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
    cout<<"  `BANK MANAGEMENT SYSTEM`\n";
    cout<<"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
    cout<<"\t~UNION BANK OF INDIA~\n";
    cout<<"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
    cout<<"1) Open account \n";
    cout<<"2) deposit money \n";
    cout<<"3) withdraw money \n";
    cout<<"4) Display account \n";
    cout<<"5) Search account \n";
    cout<<"6) show account with highest balance\n";
    cout<<"7) Exit \n";
    cout<<"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
    cout<<"\n\nselect the option from above :\n";
    cin>>ch;
    switch(ch)
    {

        case 1:"1)open account \n";
        b.open_account();
        break;

        case 2:"2) deposit money \n";
        b.deposit_money();
        break;

        case 3:"3)withdraw money \n";
        b.withdraw_money();
        break;

        case 4:"4)display account \n";
        b.Display_account();
        break;

        case 5:"5)search account \n";
        b.search_account();
        break;

        case 6:"show account with highest balance\n";
        b.show_account();
        break;

        case 7:
            if(ch==6)
            {
                exit(1);
            }


        default:
            cout<<"invalid \n";

        /*default:
            cout<<"this is not exists try again \n";
            cout<<"\n do you want to select next option then press :y \n";
            cout<<"if you want to exit then press :N";
            //x=getch();
           x=0;
            if(x=='n' || x=='N')
            exit(0);

}while(x=='y' || x=='Y');
*/

}
}
}


